﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;
using Verse.AI;

namespace Avali
{
	public class MentalState_AvaliPreparesToGo : MentalState
	{
		public override void PreStart()
		{
			
		}
	}
}
